var searchData=
[
  ['dispatchevent_10',['dispatchEvent',['../classace__button_1_1ButtonConfig.html#abb346713a5bd136a39d5e6fb16892996',1,'ace_button::ButtonConfig']]]
];
